const express = require('express')
const path = require('path')
const fs = require('fs')
const body = require('body-parser')
const { urlencoded } = require('body-parser')
const app = express()
const cors = require('cors')
const port = 6060

app.use(cors())

app.use('/static', express.static(path.join(__dirname, '../server')))

app.use(body.urlencoded({ extended: false }))
app.use(body.json())

// code = 0 成功
// code = 1 不存在用户
// code = 2 密码错误
// code = 3 封禁期
app.post('/login', (req, res) => {
  const { username, password } = req.body
  const info = JSON.parse(fs.readFileSync('./admin.json'))
  const t = new Date().getTime()

  if (info.chance === 0) {
    if ((t - info.expires) < 3000){
      return res.send({ code: 3, msg: `没有机会了, 等待${3}秒后重试` })
    } else {
      info.chance = 3
    }
  }

  console.log(info, username, password)
  if (username !== info.username) {
    return res.send({
      code: 1,
      msg: '不存在该用户',
      info: {
        username,
        password
      }
    })
  }

  if (username === info.username && password !== info.password) {
    info.chance--
    info.expires = new Date().getTime()
    fs.writeFileSync('./admin.json', JSON.stringify(info))
    return res.send({ code: 2, msg:`密码错误, 还有${info.chance}次机会` })
  }

  info.chance = 3
  info.expires = 0
  fs.writeFileSync('./admin.json', JSON.stringify(info))

  res.send({
    code: 0,
    msg: '成功登录',
    info: {
      username,
      password
    }
  })
})

app.get('/getInfo', (req, res) => {

  const list = JSON.parse(fs.readFileSync('./data.json'))

  res.send({
    code: 0,
    msg: 'info',
    list
  })
})

// 0 => 添加信息成功 | 1 => 添加信息失败 | 3 => 修改信息
app.post('/addInfo', (req, res) => {
  const info = req.body

  const list = JSON.parse(fs.readFileSync('./data.json'))
  let has = false
  list.forEach(item => {
    if (item.username === info.username) {
      item.password = info.password
      item.gender = info.gender
      item.age = info.age
      has = true
    }
  })

  if (has) {
    fs.writeFile('./data.json', JSON.stringify(list), err => {
      if (err) res.send({ code: 1, msg: '修改文件错误' })
      res.send({
        code: 3,
        msg: '修改成功 ',
        info
      })
    })
  }

  if (!has) {
    list.push({ ...info })
    fs.writeFile('./data.json', JSON.stringify(list), err => {
      if (err) res.send({ code: 1, msg: '添加文件错误' })
      res.send({
        code: 0,
        msg: '添加文件成功',
        info
      })
    })
  }

})

app.get('/deleteOne/:username', (req, res) => {
  const { username } = req.params
  console.log(username)
  const list = JSON.parse(fs.readFileSync('./data.json'))
  const resList = list.filter(item => {
    return item.username !== username
  })
  console.log(resList)

  fs.writeFile('./data.json', JSON.stringify(resList), err => {
    if (err) res.send({ code: 1, msg: '删除失败' })
    res.send({
      code: 0,
      msg: '删除成功',
      list: resList
    })
  })
})

app.post('/deleteMany', (req, res) => {
  const nameList = req.body
  const list = JSON.parse(fs.readFileSync('./data.json'))

  const resList = list.filter(item => {
    return !nameList.includes(item.username)
  })

  fs.writeFile('./data.json', JSON.stringify(resList), err => {
    if (err) res.send({ code: 1, msg: '删除失败' })
    res.send({
      code: 0,
      msg: '删除成功',
      list: resList
    })
  })
})

app.post('/changename', (req, res) => {
  const { newName, oldName } = req.body
  const list = JSON.parse(fs.readFileSync('./data.json'))

  const has = list.findIndex(item => (item.username === newName))

  if (has !== -1) res.send({ code: 1, msg: '已经存在该用户' })

  list.forEach(item => {
    if (item.username === oldName) item.username = newName
  })
  
  fs.writeFile('./data.json', JSON.stringify(list), err => {
    if (err) res.send({ code: 1, msg: '修改失败' })
    res.send({
      code: 0,
      msg: '修改成功',
      list: list
    })
  })
})

app.listen(port, () => {
  console.log(`
  服务器启动成功
  监听端口: ${port}
`)
})